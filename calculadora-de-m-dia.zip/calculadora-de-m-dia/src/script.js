var nome = "Anderson"
var notaPrimeiroBimestre = 9
var notaSegundoBimestre = 7
var notaTerceiroBimestre = 3
var notaQuartoBimestre = 2
var notaFinal = ( notaPrimeiroBimestre + notaSegundoBimestre + notaTerceiroBimestre + notaQuartoBimestre ) / 4

console.log("Bem Vindo " + nome)
console.log("Sua nota final foi " + notaFinal.toFixed(1))